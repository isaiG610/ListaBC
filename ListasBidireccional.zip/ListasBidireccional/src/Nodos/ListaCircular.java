/*
Gonzalez Nuñez Isai
Zuñiga de Leon Bryan
 */
package Nodos;

import back_end.Pagina;


public class ListaCircular {

    
    public record Resultado(Pagina pagina, int posicion) { }

    private Nodo primero;
    private Nodo ultimo;
    private int tamano;

    public ListaCircular() {
        this.primero = null;
        this.ultimo = null;
        this.tamano = 0;
    }

    
    public void insertarAlPrincipio(Pagina pagina) {
        Nodo nuevo = new Nodo(pagina);
        if (primero == null) {
            enlazarUnicoNodo(nuevo);
        } else {
            nuevo.setSiguiente(primero);   
            nuevo.setAnterior(ultimo);     
            ultimo.setSiguiente(nuevo);    
            primero.setAnterior(nuevo);    
            primero = nuevo;               
        }
        tamano++;
    }

    
    public void insertarAlFinal(Pagina pagina) {
        Nodo nuevo = new Nodo(pagina);
        if (ultimo == null) {
            enlazarUnicoNodo(nuevo);
        } else {
            nuevo.setAnterior(ultimo);     
            nuevo.setSiguiente(primero);   
            ultimo.setSiguiente(nuevo);    
            primero.setAnterior(nuevo);    
            ultimo = nuevo;                
        }
        tamano++;
    }

    
    public void insertarEnPosicion(Pagina pagina, int posicion) {
        if (posicion < 0 || posicion > tamano) {
            throw new IndexOutOfBoundsException(
                    "Posición inválida: " + posicion + ". Rango permitido: 0 a " + tamano + ".");
        }
        if (posicion == 0) {
            insertarAlPrincipio(pagina);
            return;
        }
        if (posicion == tamano) {
            insertarAlFinal(pagina);
            return;
        }
        Nodo nuevo = new Nodo(pagina);
        Nodo sucesor = nodoEn(posicion);          
        Nodo predecesor = sucesor.getAnterior();  
        nuevo.setAnterior(predecesor);
        nuevo.setSiguiente(sucesor);
        predecesor.setSiguiente(nuevo);
        sucesor.setAnterior(nuevo);
        tamano++;
    }

    
    public Pagina removerAlPrincipio() {
        validarNoVacia();
        Nodo removido = primero;
        if (tamano == 1) {
            vaciar();
            return removido.getDato();
        }
        primero = removido.getSiguiente();
        ultimo.setSiguiente(primero);   
        primero.setAnterior(ultimo);    
        aislar(removido);
        tamano--;
        return removido.getDato();
    }

    
    public Pagina removerAlFinal() {
        validarNoVacia();
        Nodo removido = ultimo;
        if (tamano == 1) {
            vaciar();
            return removido.getDato();
        }
        ultimo = removido.getAnterior();
        ultimo.setSiguiente(primero);   
        primero.setAnterior(ultimo);    
        aislar(removido);
        tamano--;
        return removido.getDato();
    }

   
    public Pagina removerEnPosicion(int posicion) {
        validarNoVacia();
        validarPosicion(posicion);
        if (posicion == 0) {
            return removerAlPrincipio();
        }
        if (posicion == tamano - 1) {
            return removerAlFinal();
        }
        Nodo removido = nodoEn(posicion);
        Nodo anterior = removido.getAnterior();
        Nodo siguiente = removido.getSiguiente();
        anterior.setSiguiente(siguiente);
        siguiente.setAnterior(anterior);
        aislar(removido);
        tamano--;
        return removido.getDato();
    }



    public Pagina mostrarAlPrincipio() {
        validarNoVacia();
        return primero.getDato();
    }

    public Pagina mostrarAlFinal() {
        validarNoVacia();
        return ultimo.getDato();
    }

    public Pagina mostrarEnPosicion(int posicion) {
        validarNoVacia();
        validarPosicion(posicion);
        return nodoEn(posicion).getDato();
    }

    
    public Resultado siguiente(int posicion) {
        validarNoVacia();
        validarPosicion(posicion);
        Nodo destino = nodoEn(posicion).getSiguiente();
        return new Resultado(destino.getDato(), posicion == tamano - 1 ? 0 : posicion + 1);
    }

    
    public Resultado anterior(int posicion) {
        validarNoVacia();
        validarPosicion(posicion);
        Nodo destino = nodoEn(posicion).getAnterior();
        return new Resultado(destino.getDato(), posicion == 0 ? tamano - 1 : posicion - 1);
    }

   
    public Resultado buscarPorValor(String url) {
        if (url == null || primero == null) {
            return null;
        }
        String clave = url.trim();
        Nodo actual = primero;
        for (int indice = 0; indice < tamano; indice++) {
            if (actual.getDato().url().equalsIgnoreCase(clave)) {
                return new Resultado(actual.getDato(), indice);
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

   
    public Resultado buscarPorPosicion(int posicion) {
        validarNoVacia();
        validarPosicion(posicion);
        return new Resultado(nodoEn(posicion).getDato(), posicion);
    }

   
    public String recorrerAdelante() {
        StringBuilder sb = new StringBuilder();
        Nodo actual = primero;
        for (int i = 0; i < tamano; i++) {
            sb.append(i).append(": ").append(actual.getDato().url()).append('\n');
            actual = actual.getSiguiente();
        }
        return sb.toString();
    }

   
    public String recorrerAtras() {
        StringBuilder sb = new StringBuilder();
        Nodo actual = ultimo;
        for (int i = tamano - 1; i >= 0; i--) {
            sb.append(i).append(": ").append(actual.getDato().url()).append('\n');
            actual = actual.getAnterior();
        }
        return sb.toString();
    }

    
    public void vaciar() {
        primero = null;
        ultimo = null;
        tamano = 0;
    }

    public boolean estaVacia() {
        return primero == null;
    }

    public int obtenerTamano() {
        return tamano;
    }

    public Nodo getPrimero() {
        return primero;
    }

    public Nodo getUltimo() {
        return ultimo;
    }

   
    private void enlazarUnicoNodo(Nodo nuevo) {
        nuevo.setSiguiente(nuevo);
        nuevo.setAnterior(nuevo);
        primero = nuevo;
        ultimo = nuevo;
    }

    private void aislar(Nodo nodo) {
        nodo.setSiguiente(null);
        nodo.setAnterior(null);
    }

    private void validarNoVacia() {
        if (estaVacia()) {
            throw new IllegalStateException("La lista está vacía.");
        }
    }

    private void validarPosicion(int posicion) {
        if (posicion < 0 || posicion >= tamano) {
            throw new IndexOutOfBoundsException(
                    "Posición inválida: " + posicion + ". Rango permitido: 0 a " + (tamano - 1) + ".");
        }
    }

  
    private Nodo nodoEn(int posicion) {
        Nodo actual;
        if (posicion <= tamano / 2) {
            actual = primero;
            for (int i = 0; i < posicion; i++) {
                actual = actual.getSiguiente();
            }
        } else {
            actual = ultimo;
            for (int i = tamano - 1; i > posicion; i--) {
                actual = actual.getAnterior();
            }
        }
        return actual;
    }
}
